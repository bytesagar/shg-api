import { Request, Response } from "express";
import { BaseController } from "../../core/base.controller";
import { AuthService } from "./auth.service";
import { HTTP_STATUS } from "../../config/constants";
import { catchAsync } from "../../utils/catch-async";
import { AppError } from "../../utils/app-error";

export class AuthController extends BaseController {
  private authService: AuthService;

  constructor() {
    super();
    this.authService = new AuthService();
  }

  public login = catchAsync(async (req: Request, res: Response) => {
    const { email, password } = req.body;

    if (!email || !password) {
      throw new AppError(
        "Email and password are required",
        HTTP_STATUS.BAD_REQUEST,
      );
    }

    const result = await this.authService.login(email, password);

    return this.ok(res, result, "Login successful");
  });

  public refresh = catchAsync(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      throw new AppError("Refresh token is required", HTTP_STATUS.BAD_REQUEST);
    }
    const result = await this.authService.refresh(refreshToken);
    return this.ok(res, result, "Token refreshed successfully");
  });

  public logout = catchAsync(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      throw new AppError("Refresh token is required", HTTP_STATUS.BAD_REQUEST);
    }
    await this.authService.logout(refreshToken);
    return this.ok(res, null, "Logout successful");
  });
}

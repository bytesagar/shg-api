import { db } from "../../db";
import {
  audit_events,
  auth_sessions,
  user_role_assignments,
  user_roles,
  users,
} from "../../db/schema";
import { and, desc, eq } from "drizzle-orm";
import * as bcrypt from "bcryptjs";
import { signJwt } from "../../utils/jwt";
import { randomBytes, createHash } from "crypto";

export class AuthService {
  private readonly accessTokenTtlMs = 24 * 60 * 60 * 1000;
  private readonly refreshTokenTtlMs = 7 * 24 * 60 * 60 * 1000;

  private hashToken(token: string) {
    return createHash("sha256").update(token).digest("hex");
  }

  public async login(email: string, password: string) {
    const userResult = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    const foundUser = userResult[0];

    if (!foundUser) {
      throw new Error("Invalid credentials");
    }

    if (
      foundUser.accountStatus === "locked" &&
      foundUser.lockedUntil &&
      foundUser.lockedUntil > new Date()
    ) {
      throw new Error("Account is temporarily locked");
    }

    const isPasswordValid = await bcrypt.compare(password, foundUser.passwordHash);

    if (!isPasswordValid) {
      const attempts = (foundUser.failedLoginAttempts ?? 0) + 1;
      await db
        .update(users)
        .set({
          failedLoginAttempts: attempts,
          lockedUntil: attempts >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null,
          accountStatus: attempts >= 5 ? "locked" : foundUser.accountStatus,
          updatedAt: new Date(),
        })
        .where(eq(users.id, foundUser.id));
      throw new Error("Invalid credentials");
    }

    if (!foundUser.facilityId) {
      throw new Error("User is not associated with a facility");
    }

    const roleAssignment = await db
      .select({
        roleName: user_roles.name,
      })
      .from(user_role_assignments)
      .innerJoin(user_roles, eq(user_role_assignments.roleId, user_roles.id))
      .where(
        and(
          eq(user_role_assignments.userId, foundUser.id),
          eq(user_role_assignments.isPrimary, true),
        ),
      )
      .orderBy(desc(user_role_assignments.createdAt))
      .limit(1);
    const resolvedRole = roleAssignment[0]?.roleName ?? foundUser.userType;

    const refreshToken = randomBytes(48).toString("hex");
    const refreshTokenHash = this.hashToken(refreshToken);
    const sessionInserted = await db
      .insert(auth_sessions)
      .values({
        userId: foundUser.id,
        refreshTokenHash,
        status: "active",
        expiresAt: new Date(Date.now() + this.refreshTokenTtlMs),
        issuedAt: new Date(),
        lastUsedAt: new Date(),
      })
      .returning({ id: auth_sessions.id });
    const sessionId = sessionInserted[0]?.id;

    const token = signJwt(
      {
        id: foundUser.id,
        email: foundUser.email,
        role: resolvedRole,
        userType: foundUser.userType,
        facilityId: foundUser.facilityId,
        sessionId,
      },
      { expiresIn: "1d" },
    );

    await db
      .update(users)
      .set({
        failedLoginAttempts: 0,
        lockedUntil: null,
        accountStatus: "active",
        lastLoginAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, foundUser.id));

    await db.insert(audit_events).values({
      actorUserId: foundUser.id,
      actorPersonId: foundUser.personId,
      action: "login.success",
      resourceType: "User",
      resourceId: foundUser.id,
      outcome: "success",
      facilityId: foundUser.facilityId,
    });

    const { passwordHash: _passwordHash, ...userWithoutPassword } = foundUser;

    return {
      user: userWithoutPassword,
      token,
      refreshToken,
      sessionId,
    };
  }

  public async refresh(refreshToken: string) {
    const refreshTokenHash = this.hashToken(refreshToken);
    const [session] = await db
      .select()
      .from(auth_sessions)
      .where(eq(auth_sessions.refreshTokenHash, refreshTokenHash))
      .limit(1);
    if (!session || session.status !== "active" || session.expiresAt < new Date()) {
      throw new Error("Invalid refresh token");
    }

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId))
      .limit(1);
    if (!user || !user.facilityId) {
      throw new Error("Invalid session user");
    }

    const roleAssignment = await db
      .select({
        roleName: user_roles.name,
      })
      .from(user_role_assignments)
      .innerJoin(user_roles, eq(user_role_assignments.roleId, user_roles.id))
      .where(
        and(
          eq(user_role_assignments.userId, user.id),
          eq(user_role_assignments.isPrimary, true),
        ),
      )
      .orderBy(desc(user_role_assignments.createdAt))
      .limit(1);
    const resolvedRole = roleAssignment[0]?.roleName ?? user.userType;

    const newRefreshToken = randomBytes(48).toString("hex");
    const newRefreshTokenHash = this.hashToken(newRefreshToken);
    await db
      .update(auth_sessions)
      .set({
        refreshTokenHash: newRefreshTokenHash,
        lastUsedAt: new Date(),
        expiresAt: new Date(Date.now() + this.refreshTokenTtlMs),
        updatedAt: new Date(),
      })
      .where(eq(auth_sessions.id, session.id));

    const accessToken = signJwt(
      {
        id: user.id,
        email: user.email,
        role: resolvedRole,
        userType: user.userType,
        facilityId: user.facilityId,
        sessionId: session.id,
      },
      { expiresIn: `${Math.floor(this.accessTokenTtlMs / 1000)}s` },
    );

    await db.insert(audit_events).values({
      actorUserId: user.id,
      actorPersonId: user.personId,
      action: "session.refresh",
      resourceType: "AuthSession",
      resourceId: session.id,
      outcome: "success",
      facilityId: user.facilityId,
    });

    return {
      token: accessToken,
      refreshToken: newRefreshToken,
      sessionId: session.id,
    };
  }

  public async logout(refreshToken: string) {
    const refreshTokenHash = this.hashToken(refreshToken);
    const [session] = await db
      .select()
      .from(auth_sessions)
      .where(eq(auth_sessions.refreshTokenHash, refreshTokenHash))
      .limit(1);
    if (!session) return;

    await db
      .update(auth_sessions)
      .set({
        status: "revoked",
        revokedAt: new Date(),
        revokedReason: "user_logout",
        updatedAt: new Date(),
      })
      .where(eq(auth_sessions.id, session.id));

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId))
      .limit(1);
    if (user?.facilityId) {
      await db.insert(audit_events).values({
        actorUserId: user.id,
        actorPersonId: user.personId,
        action: "logout",
        resourceType: "AuthSession",
        resourceId: session.id,
        outcome: "success",
        facilityId: user.facilityId,
      });
    }
  }
}
